# Expensely

## Setup
1. Copy `.env.example` to `.env`
2. Run `npm install`
3. Start with `npm run dev`

## Deployment
Use Firebase or Docker setup included.